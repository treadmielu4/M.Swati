
import { Injectable } from '@angular/core';
import { IEmployee } from './employee';
import {HttpClient} from '@angular/common/http'
// The @Injectable() decorator is used to inject other dependencies
// into this service. As our service does not have any dependencies
// at the moment, we may remove the @Injectabyesle() decorator and the
// service works exactly the same way. However, Angular recomends
// to always use @Injectable() decorator to ensures consistency
@Injectable()
export class EmployeeService {

    url:string="http://localhost:8030/employee"
    constructor(private httpClient:HttpClient)
    {

    }
    getEmployees() {
        return this.httpClient.get<IEmployee[]>(this.url+"/getAllEmployees");
    }

    public deleteEmployee(employee:IEmployee)
    {
        return this.httpClient.delete<IEmployee>(this.url+"/"+employee.code);
    }


}