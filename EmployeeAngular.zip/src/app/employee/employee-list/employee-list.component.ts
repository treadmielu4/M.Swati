import { Component, OnInit } from '@angular/core';
import { Employee, IEmployee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  selectedEmployeeCountRadioButton: string = 'All';
  employees: IEmployee[];
 

getEmployees(): void {
  this._employeeService.getEmployees().subscribe(response=>{
    this.employees=response;
  });
}

  constructor(private _employeeService: EmployeeService) {
  }

  ngOnInit(): void {
    this._employeeService.getEmployees().subscribe(response=>{
      this.employees=response;
    });
  }

  onEmployeeCountRadioButtonChange(selectedRadioButtonValue: string): void {
    alert("Emmiter Value="+selectedRadioButtonValue)
    this.selectedEmployeeCountRadioButton = selectedRadioButtonValue;
}


getTotalEmployeesCount(): number {
  return this.employees.length;
}

getMaleEmployeesCount(): number {
  return this.employees.filter(e => e.gender === 'Male').length;
}

getFemaleEmployeesCount(): number {
  return this.employees.filter(e => e.gender === 'Female').length;
}
trackByEmpCode(index: number, employee: any): string {
  return employee.code;
}


onDeleteEmployee(employee:Employee)
{
  this._employeeService.deleteEmployee(employee).subscribe(response=>{
    alert(response);

  });
}


}
