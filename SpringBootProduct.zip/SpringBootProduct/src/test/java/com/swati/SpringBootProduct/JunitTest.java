package com.swati.SpringBootProduct;

import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.swati.SpringBootProduct.dao.ProductDao;
import com.swati.SpringBootProduct.model.Product;
import com.swati.SpringBootProduct.service.ProductService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JunitTest {

	@MockBean
	ProductDao pd;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	ProductService ps;
	
	@Before
	public void init() {
		Product p = new Product(1,"Handwash",100.00,"Lifebuoy");
		
		when(pd.findById(1)).thenReturn(Optional.of(p));
	}
	
	
}