package com.swati.SpringBootProduct;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.swati.SpringBootProduct.dao.ProductDao;
import com.swati.SpringBootProduct.model.Product;

@Configuration
@EnableAutoConfiguration
@SpringBootApplication
public class SpringBootProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProductApplication.class, args);
		System.out.println("Product Application Is Running");
	}

	@Bean
	CommandLineRunner initDatabase(final ProductDao repository) {

		return args -> {
			repository.save(new Product(1, "Handwash", 100.00, "Lifebuoy"));
			repository.save(new Product(2, "Shampoo", 150.00, "Loreal"));
			repository.save(new Product(3, "Chocolate", 50.00, "Cadbury"));
			repository.save(new Product(4, "Hair Dryer", 800.00, "Philips"));
			repository.save(new Product(5, "Sports Shoes", 1200.00, "Nike"));
			repository.save(new Product(6, "Jeans", 1000.00, "Levis" ));
		};
	}
}
