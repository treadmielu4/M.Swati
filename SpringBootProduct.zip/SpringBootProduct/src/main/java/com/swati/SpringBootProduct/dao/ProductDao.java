package com.swati.SpringBootProduct.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.swati.SpringBootProduct.model.Product;

@Repository
public interface ProductDao extends CrudRepository<Product, Integer>{

	Optional<Product> findByName(String name);

	Optional<Product> findByPrice(double price);

	Optional<Product> findByCompany(String company);

	@Query(nativeQuery = true, value = "select * from products order by price desc limit 5;")
	List<Product> findTop5ByPrice();

}
