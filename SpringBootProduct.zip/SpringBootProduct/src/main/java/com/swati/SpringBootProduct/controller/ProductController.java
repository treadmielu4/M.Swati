package com.swati.SpringBootProduct.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.swati.SpringBootProduct.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	ProductService ps;
	
	@GetMapping("/products")
	public ResponseEntity<Object> productsList(){
		return new ResponseEntity<>(ps.allProducts(),HttpStatus.OK);
	}
	
	@GetMapping("/productById/{id}")
	public ResponseEntity<Object> productById(@PathVariable int id){
		if(ps.productById(id)==null) {
			return new ResponseEntity<>("Product Not Found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(ps.productById(id),HttpStatus.OK);
	}
	
	@GetMapping("/productByName/{name}")
	public ResponseEntity<Object> productByName(@PathVariable String name){
		if(ps.productByName(name)==null)
			return new ResponseEntity<>("Product Not Found",HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ps.productByName(name),HttpStatus.OK);
	}
	
	@GetMapping("/productByPrice/{price}")
	public ResponseEntity<Object> productByPrice(@PathVariable double price){
		if(ps.productByPrice(price)==null)
			return new ResponseEntity<>("Product Not Found",HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ps.productByPrice(price),HttpStatus.OK);
	}
	
	@GetMapping("/productByCompany/{company}")
	public ResponseEntity<Object> productByCompany(@PathVariable String company){
		if(ps.productByCompany(company)==null)
			return new ResponseEntity<>("Product Not Found",HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ps.productByCompany(company),HttpStatus.OK);
	}
	
	@GetMapping("/top5ProductsByPrice")
	public ResponseEntity<Object> top5ByPrice(){
		if(ps.top5ByPrice()==null)
			return new ResponseEntity<>("Product Not Found",HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ps.top5ByPrice(),HttpStatus.OK);
	}
}
