package com.swati.SpringBootProduct.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.swati.SpringBootProduct.dao.ProductDao;
import com.swati.SpringBootProduct.model.Product;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductDao pd;
	
	public List<Product> allProducts(){
		return (List<Product>) pd.findAll();
	}
	
	public Product productById(int id){
		return pd.findById(id).get();
	}
	
	public Product productByName(String name){
		return pd.findByName(name).get();
	}
	
	public Product productByPrice(double price) {
		return pd.findByPrice(price).get();
	}
	
	public Product productByCompany(String company) {
		return pd.findByCompany(company).get();
	}
	
	public List<Product> top5ByPrice() {
		return pd.findTop5ByPrice();
	}
}
