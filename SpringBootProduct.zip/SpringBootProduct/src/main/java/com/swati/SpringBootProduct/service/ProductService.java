package com.swati.SpringBootProduct.service;

import java.util.List;

import com.swati.SpringBootProduct.model.Product;

public interface ProductService {
	public List<Product> allProducts();
	public Product productById(int id);
	public Product productByName(String name);
	public Product productByPrice(double price);
	public Product productByCompany(String company);
	public List<Product> top5ByPrice();

}
