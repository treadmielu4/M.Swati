package com.swati.RestExample1.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.swati.RestExample1.entity.Product;
import com.swati.RestExample1.errorHandler.ProductNotFoundException;
import com.swati.RestExample1.errorHandler.ProductUnsupportedFieldPatchException;
import com.swati.RestExample1.repo.ProductRepository;

@RestController
public class ProductController {

	@Autowired
	ProductRepository pr;
	
	@GetMapping("/product")
	public List<Product> getProducts(){
		return pr.findAll();
	}
	
	@PostMapping("/product")
	public Product saveProducts(@RequestBody Product p) {
		return pr.save(p);
	}
	
	@GetMapping("/product/{id}")
	public Optional<Product> getProductById(@PathVariable int id) {
		return pr.findById(id);
	}
	
	@PutMapping("/product/{id}")
	public Product update(@RequestBody Product p, @PathVariable int id) {
		return pr.findById(id).map(x -> {
			x.setName(p.getName());
			x.setCompany(p.getCompany());
			x.setPrice(p.getPrice());
			return pr.save(x);
		})
				.orElseGet(() -> {
					p.setId(id);
					return pr.save(p);
				});
	}
	
	
	@PatchMapping("/product/{id}")
	public Product patch(@RequestBody Map<String, String> update, @PathVariable int id) {
		return pr.findById(id).map(x -> {
			String company = update.get("company");
			
			if(!StringUtils.isEmpty(company)) {
				x.setCompany(company);
				return pr.save(x);
			}
			else {
				throw new ProductUnsupportedFieldPatchException(update.keySet());
			}
		})
				.orElseGet(() -> {
					throw new ProductNotFoundException(id);
				});
	}
	
	
	@DeleteMapping("/product/{id}")
    public void deleteProduct(@PathVariable int id) {
        pr.deleteById(id);
    }
}
