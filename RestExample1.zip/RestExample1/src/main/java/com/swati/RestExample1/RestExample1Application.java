package com.swati.RestExample1;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.swati.RestExample1.entity.Product;
import com.swati.RestExample1.repo.ProductRepository;

@SpringBootApplication
public class RestExample1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestExample1Application.class, args);
	}	
		@Bean
	    CommandLineRunner initDatabase(ProductRepository pr) {
	        return args -> {
	            pr.save(new Product(1,"Jeans", "Levis",1100.00));
	            pr.save(new Product(2,"Dryer", "Philips",800.00));
	            pr.save(new Product(3,"Mobile", "Samsung",10000.00));
	        };
	}

}
