package com.swati.RestExample1.errorHandler;

public class ProductNotFoundException extends RuntimeException {
	 
	public ProductNotFoundException(int id) {
		super("Product Not Found : "+id);
	}

}
