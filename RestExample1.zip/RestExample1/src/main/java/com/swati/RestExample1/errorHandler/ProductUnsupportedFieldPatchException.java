package com.swati.RestExample1.errorHandler;

import java.util.Set;

public class ProductUnsupportedFieldPatchException extends RuntimeException {

	public ProductUnsupportedFieldPatchException(Set<String> keys) {
		super("Field " +keys.toString()+ " update is not allowed");
	}
}
