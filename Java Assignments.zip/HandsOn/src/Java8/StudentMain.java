package Java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StudentMain {

	public static void main(String[] args) {
		
		Student s1 = new Student("Ram",45,new Address("1235"),Arrays.asList(new MobileNumber("1234"),new MobileNumber("1233")));
		Student s2 = new Student("Jayesh",40,new Address("1115"),Arrays.asList(new MobileNumber("1111"), new MobileNumber("3333"), new MobileNumber("1233")));
		Student s3 = new Student("Shyam",37,new Address("5588"),Arrays.asList(new MobileNumber("3333"), new MobileNumber("4444")));
		
		List<Student> s = Arrays.asList(s1,s2,s3);
		
		// 1. Get student with exact match name "jayesh"
		Optional<Student> filter = s.stream().filter((i)->i.getName().equalsIgnoreCase("jayesh")).findFirst();
		if(filter.isPresent())
			System.out.println(filter.get().getName());
		else
			System.out.println("Not Found");
		
		
		// 2. Get student with matching address "1235"
		Optional<Student> filter2 = s.stream().filter((i)->i.getAddress().getZipcode().equals("1235")).findFirst();
		if(filter2.isPresent())
			System.out.println(filter2.get().getName());
		else
			System.out.println("Not Found");
		
		
		// 3. Get all student having mobile numbers 3333.
		List<Student> filter3 = s.stream().filter((i)->i.getMobileNumbers().stream().anyMatch(x -> Objects.equals(x.getNumber(), "3333"))).collect(Collectors.toList());
		System.out.println(filter3.stream().map(i -> i.getName()).collect(Collectors.toList()));
		
		
		// 4. Get all student having mobile number 1233 and 1234
		List<Student> stud3 = s.stream()
	            .filter(student -> student.getMobileNumbers().stream().allMatch(x -> Objects.equals(x.getNumber(),"1233") || Objects.equals(x.getNumber(),"1234")))
	            .collect(Collectors.toList());
	 
	        System.out.println(stud3.stream().map(std -> std.getName()).collect(Collectors.toList()));
	        
		
	    // 5. Create a List<Student> from the List<TempStudent>
	        TempStudent ts1 = new TempStudent("Jayesh1",40,new Address("12341"),Arrays.asList(new MobileNumber("12331"), new MobileNumber("12341")));
	        TempStudent ts2 = new TempStudent("Ram1",35,new Address("12351"),Arrays.asList(new MobileNumber("11111"), new MobileNumber("33331"), new MobileNumber("12331")));
	     
	        List<TempStudent> ts = Arrays.asList(ts1, ts2);
	     
	        List<Student> sList = ts.stream().map(x -> new Student(x.name, x.age, x.address, x.mobileNumbers)).collect(Collectors.toList());
	        System.out.println(sList);
	    
	        
	    // 6. Convert List<Student> to List<String> of student name
	     List<String> sName = sList.stream().map(Student::getName).collect(Collectors.toList());
	     System.out.println(sName.stream().collect(Collectors.toList()));
	     
	     
	    // 7. Convert List<students> to String
	     List<String> sName1 = s.stream().map(Student::getName).collect(Collectors.toList());
	     System.out.println(sName1.stream().collect(Collectors.toList()));
	     
	     
	    // 8. Change the case of List<String>
	     List<String> caseChange = s.stream().map(Student::getName).map(String::toUpperCase).collect(Collectors.toList());
	     System.out.println(caseChange.stream().collect(Collectors.toList()));
	     
	     
	    // 9. Sort List<String>
	     List<String> sorting = s.stream().map(Student::getName).sorted().collect(Collectors.toList());
	     System.out.println(sorting.stream().collect(Collectors.toList()));
	     
	     
	    // 10. Conditionally apply Filter condition, say if flag is enabled then 
	     boolean flag = true;
	        Stream<Student> res = s.stream().filter(st -> st.getName().startsWith("J"));
	        
	        if(flag)
	            res = res.sorted(Comparator.comparing(Student::getName));
	 
	        List<Student> list = res.collect(Collectors.toList());
	        System.out.print("Using Flag : ");
	        list.forEach(st -> System.out.println(st.getName()));
	}

}
