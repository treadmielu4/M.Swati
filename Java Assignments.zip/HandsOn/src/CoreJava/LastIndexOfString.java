package CoreJava;
import java.util.Scanner;

public class LastIndexOfString {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a string");
		String s = in.nextLine();
		System.out.println("Last index of a string is:" +s.lastIndexOf("co"));
	}

}
