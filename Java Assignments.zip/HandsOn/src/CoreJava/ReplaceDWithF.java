package CoreJava;
import java.util.Scanner;

public class ReplaceDWithF {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a string");
		String s = in.nextLine();
		System.out.println("After replacing D with F: "+s.replace("d", "f"));

	}

}
