package CoreJava;

public class VariablesParametersMain {

	public static void main(String[] args) {
		VariablesParameters vp = new VariablesParameters(014, "swati", "cse");
		float [] marks = {78,94,89,92,70,85,82};
		float maxMarks = 100;
		vp.percentage(marks, maxMarks);
		System.out.println(vp.getPercent());

	}

}
