package CoreJava;
import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = in.nextInt();
		int n,r,total=0;
		n=num;
		while(n!=0) {
			r = n%10;
			total = total + r*r*r;
			n = n/10;
		}
		if(total==num)
			System.out.println("It is an armstrong number");
		else
			System.out.println("It is not an armstrong number");

	}

}
