package CoreJava;

public class StringMatching {

	public static void main(String[] args) {
		String s1 = "Welcome to the adm training session";
		String s2 = "train";
		System.out.println(s1.regionMatches(19, s2, 0, 5));
		
	}

}
