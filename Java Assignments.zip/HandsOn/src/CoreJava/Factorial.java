package CoreJava;
import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int fact = 1;
		System.out.println("Enter the no whos factorial you want to find");
		int num = in.nextInt();
		while(num>0) {
			fact = fact*num;
			num--;
		}
		System.out.println(fact);
	}

}
