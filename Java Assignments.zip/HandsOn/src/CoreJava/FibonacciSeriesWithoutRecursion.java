package CoreJava;
import java.util.Scanner;

public class FibonacciSeriesWithoutRecursion {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the size of the series");
		int n = in.nextInt();
		int a = 0, b = 1,c;
		System.out.print(a+" "+b);
		for(int i = 2; i<n ; i++) {
			c = a + b;
			System.out.print(" "+c);
			a = b;
			b = c;
		}
	}

}
