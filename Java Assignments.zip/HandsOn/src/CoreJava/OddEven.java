package CoreJava;
import java.util.Scanner;

public class OddEven {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n = in.nextInt();
		System.out.println("Enter the numbers");
		int arr[] = new int[n];
		for(int i=0 ; i<n; i++) {
			arr[i] = in.nextInt();
		}
		
		for(int i=0; i<n; i++) {
			if(arr[i]%2==0)
				System.out.println("Even");
			else
				System.out.println("Odd");
		}
	}

}
