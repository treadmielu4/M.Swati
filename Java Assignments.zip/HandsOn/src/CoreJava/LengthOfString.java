package CoreJava;
import java.util.Scanner;

public class LengthOfString {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a string");
		String s = in.nextLine();
		System.out.println("Length of String is:"+s.length());

	}

}
