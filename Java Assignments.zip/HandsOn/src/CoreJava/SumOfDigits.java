package CoreJava;
import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = in.nextInt();
		int r,sum=0;
		while(num>0) {
			r = num%10;
			sum = sum + r;
			num = num/10;
		}
		System.out.println("Sum of digits of an integer is: "+sum);
	}

}
