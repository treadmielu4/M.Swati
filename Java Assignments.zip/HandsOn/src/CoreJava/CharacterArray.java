package CoreJava;
import java.util.Scanner;

public class CharacterArray {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a string");
		String s = in.nextLine();
		char arr[] = s.toCharArray();
		System.out.println(arr);
	}

}
