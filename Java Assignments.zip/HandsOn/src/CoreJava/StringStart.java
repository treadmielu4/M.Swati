package CoreJava;

public class StringStart {

	public static void main(String[] args) {
		String s1 = "Training conducted for nominated students";
		String s2 = "Training";
		
		System.out.println(s1.startsWith(s2,0));
	}

}
