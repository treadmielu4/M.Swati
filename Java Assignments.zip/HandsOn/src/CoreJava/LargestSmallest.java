package CoreJava;
import java.util.Scanner;

public class LargestSmallest {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n = in.nextInt();
		int large,small;
		int arr[] = new int[n];
		for(int i=0; i<n; i++) {
			arr[i] = in.nextInt();
		}
		large = small = arr[0];
		for(int i=1; i<arr.length; i++) {
			
			if(arr[i]>large)
				large = arr[i];
			if(arr[i]<small)
				small = arr[i];
				
		}
		System.out.println("Largest Number in array is : "+large);
		System.out.println("Smallest Number in array is : "+small);
	}

}
