package CoreJava;
import java.util.Iterator;
import java.util.Stack;

public class StackImplementation {

	public static void main(String[] args) {
		
		Stack<String> s = new Stack<>();
		
		//PUSH
		s.push("Welcome");
		s.push("To");
		s.push("Cognizant");
		
		System.out.print(s);
		System.out.println();
		
		//POP
		s.pop();
		System.out.print(s);
		/*Iterator<String> i = s.iterator();
		while(i.hasNext()) {
			
		}*/		
		System.out.println();
		
		//PEEK
		s.peek();
		System.out.print(s);
		System.out.println();
		
		//ISEMPTY
		System.out.println(s.isEmpty());
		
		//ISFULL
	}

}
