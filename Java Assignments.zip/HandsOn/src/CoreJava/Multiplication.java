package CoreJava;
import java.util.Scanner;

public class Multiplication {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = in.nextInt();
		
		//USING FOR LOOP
		for(int i=1; i<=10; i++) {
			int mul = num*i;
			System.out.println(+num+"*"+i+"="+mul);
		}
		
		
		//USING WHILE LOOP
		int i = 1;
		while(i<=10) {
			int mul = num*i;
			System.out.println(+num+"*"+i+"="+mul);
			i++;
		}
		
		
		//USING DO-WHILE LOOP
		int j = 1;
		do {
			int mul = num*j;
			System.out.println(+num+"*"+j+"="+mul);
			j++;
		}
		while(j<=10);
	}

}
