package CoreJava;

public class ReplaceFoxWithCat {

	public static void main(String[] args) {
		String s = "The quick brown fox jumps over the lazy dog";
		System.out.println("Before replacement:\n" +s);
		System.out.println();
		System.out.println("After replacing fox with cat:\n" +s.replaceAll("fox", "cat"));
	}

}
